int TryDirectConvert(char *command);
void WriteCFGFontNumber(char **cfg_stream);
