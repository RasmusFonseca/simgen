int             my_getopt(int argc, char **argv, char *optstring);
