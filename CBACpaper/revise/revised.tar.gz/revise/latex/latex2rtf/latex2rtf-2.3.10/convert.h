void ConvertString(const char *string);
void ConvertAllttString(char *s);
void Convert(void);

